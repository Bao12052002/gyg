<?php
require_once __DIR__ . '/../utils/Database.php';

class Availability {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function getAvailabilities($productId, $fromDateTime, $toDateTime) {
        $stmt = $this->db->prepare("
            SELECT a.*, vbc.category, vbc.vacancies AS vbc_vacancies, 
                   pc.category AS pc_category, pc.price AS pc_price,
                   tpc.category AS tpc_category, tpc.tier_min, tpc.tier_max, tpc.price AS tpc_price
            FROM availabilities a
            LEFT JOIN vacancies_by_category vbc ON a.id = vbc.availability_id
            LEFT JOIN prices_by_category pc ON a.id = pc.availability_id
            LEFT JOIN tiered_prices_by_category tpc ON a.id = tpc.availability_id
            WHERE a.product_id = ? AND a.date_time BETWEEN ? AND ?
        ");
        $stmt->execute([$productId, $fromDateTime, $toDateTime]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $availabilities = [];
        foreach ($rows as $row) {
            $availId = $row['id'];
            if (!isset($availabilities[$availId])) {
                $availabilities[$availId] = [
                    'dateTime' => $row['date_time'],
                    'productId' => $row['product_id'],
                    'vacancies' => $row['vacancies'],
                    'cutoffSeconds' => $row['cutoff_seconds'],
                    'currency' => $row['currency'],
                    'openingTimes' => $row['opening_from_time'] ? [
                        'fromTime' => $row['opening_from_time'],
                        'toTime' => $row['opening_to_time']
                    ] : null,
                    'vacanciesByCategory' => [],
                    'pricesByCategory' => ['retailPrices' => []],
                    'tieredPricesByCategory' => []
                ];
            }

            if ($row['vbc_category']) {
                $availabilities[$availId]['vacanciesByCategory'][] = [
                    'category' => $row['vbc_category'],
                    'vacancies' => $row['vbc_vacancies']
                ];
            }

            if ($row['pc_category']) {
                $availabilities[$availId]['pricesByCategory']['retailPrices'][] = [
                    'category' => $row['pc_category'],
                    'price' => $row['pc_price']
                ];
            }

            if ($row['tpc_category']) {
                $availabilities[$availId]['tieredPricesByCategory'][] = [
                    'category' => $row['tpc_category'],
                    'tier' => [
                        'min' => $row['tier_min'],
                        'max' => $row['tier_max']
                    ],
                    'price' => $row['tpc_price']
                ];
            }
        }

        return array_values($availabilities);
    }
}
?>