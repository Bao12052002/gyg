<?php
header('Content-Type: application/json');
http_response_code(500);
echo json_encode([
    'errorCode' => 'INTERNAL_SYSTEM_FAILURE',
    'errorMessage' => 'An unexpected error occurred.'
]);
?>