<?php
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Availability.php';
require_once __DIR__ . '/../models/Reservation.php';
require_once __DIR__ . '/../utils/Response.php';

class ReservationController {
    public function reserve() {
        $input = json_decode(file_get_contents('php://input'), true);
        $data = $input['data'] ?? [];

        // Validate input
        if (!isset($data['productId'], $data['dateTime'], $data['bookingItems'], $data['gygBookingReference'])) {
            Response::error('VALIDATION_FAILURE', 'Missing required fields.');
        }

        $productId = $data['productId'];
        $dateTime = $data['dateTime'];
        $bookingItems = $data['bookingItems'];
        $gygBookingReference = $data['gygBookingReference'];

        // Validate product
        $productModel = new Product();
        $product = $productModel->getById($productId);
        if (!$product) {
            Response::error('INVALID_PRODUCT', 'The specified product does not exist.');
        }

        // Validate dateTime
        if (!DateTime::createFromFormat(DateTime::ISO8601, $dateTime)) {
            Response::error('VALIDATION_FAILURE', 'Invalid dateTime format.');
        }

        // Check availability
        $availabilityModel = new Availability();
        $availabilities = $availabilityModel->getAvailabilities($productId, $dateTime, $dateTime);
        if (empty($availabilities)) {
            Response::error('NO_AVAILABILITY', 'No availability for the requested dateTime.');
        }

        $availability = $availabilities[0];
        $totalRequested = array_sum(array_column($bookingItems, 'count'));
        $availableVacancies = $availability['vacancies'] ?? array_sum(array_column($availability['vacanciesByCategory'], 'vacancies'));
        if ($totalRequested > $availableVacancies) {
            Response::error('NO_AVAILABILITY', "Requested $totalRequested; available $availableVacancies.");
        }

        // Validate ticket categories
        $pricingModel = new Product();
        $pricingCategories = $pricingModel->getPricingCategories($productId);
        $validCategories = array_column($pricingCategories, 'category');
        foreach ($bookingItems as $item) {
            if (!in_array($item['category'], $validCategories)) {
                Response::error('INVALID_TICKET_CATEGORY', "The ticket category {$item['category']} is not sellable.");
            }
        }

        // Create reservation
        $reservationReference = uniqid('res_');
        $reservationExpiration = (new DateTime())->modify('+60 minutes')->format(DateTime::ISO8601);
        $reservationModel = new Reservation();
        $reservationModel->create([
            'reservation_reference' => $reservationReference,
            'product_id' => $productId,
            'gyg_booking_reference' => $gygBookingReference,
            'date_time' => $dateTime,
            'reservation_expiration' => $reservationExpiration,
            'booking_items' => $bookingItems
        ]);

        Response::success([
            'reservationReference' => $reservationReference,
            'reservationExpiration' => $reservationExpiration
        ]);
    }

    public function cancelReservation() {
        $input = json_decode(file_get_contents('php://input'), true);
        $data = $input['data'] ?? [];

        if (!isset($data['reservationReference'], $data['gygBookingReference'])) {
            Response::error('VALIDATION_FAILURE', 'Missing required fields.');
        }

        $reservationReference = $data['reservationReference'];
        $reservationModel = new Reservation();
        $reservation = $reservationModel->getByReference($reservationReference);

        if (!$reservation) {
            Response::error('INVALID_RESERVATION', 'The specified reservation does not exist.');
        }

        $reservationModel->delete($reservationReference);
        Response::success([]);
    }
}
?>