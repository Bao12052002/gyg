<?php
require_once __DIR__ . '/../utils/Database.php';
require_once __DIR__ . '/../utils/Auth.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/../controllers/AvailabilityController.php';
require_once __DIR__ . '/../controllers/BookingController.php';
require_once __DIR__ . '/../controllers/ReservationController.php';
require_once __DIR__ . '/../controllers/NotificationController.php';
require_once __DIR__ . '/../controllers/ProductController.php';

// Xác thực HTTP Basic Auth
if (!Auth::authenticate()) {
    Response::error('AUTHORIZATION_FAILURE', 'The provided authentication credentials are not valid.', 401);
}

// Lấy phương thức và đường dẫn
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = trim($path, '/');

// Định tuyến
switch ($path) {
    case '1/get-availabilities':
        if ($method === 'GET') {
            $controller = new AvailabilityController();
            $controller->getAvailabilities();
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case '1/reserve':
        if ($method === 'POST') {
            $controller = new ReservationController();
            $controller->reserve();
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case '1/book':
        if ($method === 'POST') {
            $controller = new BookingController();
            $controller->book();
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case '1/cancel-reservation':
        if ($method === 'POST') {
            $controller = new ReservationController();
            $controller->cancelReservation();
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case '1/cancel-booking':
        if ($method === 'POST') {
            $controller = new BookingController();
            $controller->cancelBooking();
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case '1/notify':
        if ($method === 'POST') {
            $controller = new NotificationController();
            $controller->notify();
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case preg_match('/^1\/suppliers\/([^\/]+)\/products$/', $path, $matches) ? true : false:
        if ($method === 'GET') {
            $controller = new ProductController();
            $controller->getSupplierProducts($matches[1]);
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case preg_match('/^1\/products\/([^\/]+)$/', $path, $matches) ? true : false:
        if ($method === 'GET') {
            $controller = new ProductController();
            $controller->getProductDetails($matches[1]);
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case preg_match('/^1\/products\/([^\/]+)\/pricing-categories$/', $path, $matches) ? true : false:
        if ($method === 'GET') {
            $controller = new ProductController();
            $controller->getPricingCategories($matches[1]);
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    case preg_match('/^1\/products\/([^\/]+)\/addons$/', $path, $matches) ? true : false:
        if ($method === 'GET') {
            $controller = new ProductController();
            $controller->getAddons($matches[1]);
        } else {
            Response::error('VALIDATION_FAILURE', 'Method not allowed.', 405);
        }
        break;

    default:
        Response::error('VALIDATION_FAILURE', 'Endpoint not found.', 404);
}
?>