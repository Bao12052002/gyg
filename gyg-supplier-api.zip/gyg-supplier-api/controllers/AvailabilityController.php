<?php
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Availability.php';
require_once __DIR__ . '/../utils/Response.php';

class AvailabilityController {
    public function getAvailabilities() {
        $productId = $_GET['productId'] ?? '';
        $fromDateTime = $_GET['fromDateTime'] ?? '';
        $toDateTime = $_GET['toDateTime'] ?? '';

        // Validate input
        if (!$productId || !$fromDateTime || !$toDateTime) {
            Response::error('VALIDATION_FAILURE', 'Missing required parameters.');
        }

        // Validate date format
        if (!DateTime::createFromFormat(DateTime::ISO8601, $fromDateTime) ||
            !DateTime::createFromFormat(DateTime::ISO8601, $toDateTime)) {
            Response::error('VALIDATION_FAILURE', 'Invalid date format.');
        }

        // Check product exists
        $productModel = new Product();
        $product = $productModel->getById($productId);
        if (!$product) {
            Response::error('INVALID_PRODUCT', 'The specified product does not exist.');
        }

        // Get availabilities
        $availabilityModel = new Availability();
        $availabilities = $availabilityModel->getAvailabilities($productId, $fromDateTime, $toDateTime);

        Response::success(['availabilities' => $availabilities]);
    }
}
?>