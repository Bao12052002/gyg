<?php
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Reservation.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../utils/Response.php';

class BookingController {
    public function book() {
        $input = json_decode(file_get_contents('php://input'), true);
        $data = $input['data'] ?? [];

        // Validate input
        if (!isset($data['productId'], $data['reservationReference'], $data['gygBookingReference'], 
                   $data['dateTime'], $data['currency'], $data['bookingItems'])) {
            Response::error('VALIDATION_FAILURE', 'Missing required fields.');
        }

        $productId = $data['productId'];
        $reservationReference = $data['reservationReference'];
        $gygBookingReference = $data['gygBookingReference'];
        $dateTime = $data['dateTime'];
        $currency = $data['currency'];
        $bookingItems = $data['bookingItems'];
        $addonItems = $data['addonItems'] ?? [];
        $travelers = $data['travelers'] ?? [];
        $travelerHotel = $data['travelerHotel'] ?? null;
        $comment = $data['comment'] ?? null;

        // Validate product
        $productModel = new Product();
        $product = $productModel->getById($productId);
        if (!$product) {
            Response::error('INVALID_PRODUCT', 'The specified product does not exist.');
        }

        // Validate reservation
        $reservationModel = new Reservation();
        $reservation = $reservationModel->getByReference($reservationReference);
        if (!$reservation) {
            Response::error('INVALID_RESERVATION', 'The specified reservation does not exist.');
        }

        if (new DateTime($reservation['reservation_expiration']) < new DateTime()) {
            Response::error('INVALID_RESERVATION', 'Expired reservation; 60min hold time was exceeded.');
        }

        // Validate ticket categories and addons
        $pricingCategories = $productModel->getPricingCategories($productId);
        $validCategories = array_column($pricingCategories, 'category');
        foreach ($bookingItems as $item) {
            if (!in_array($item['category'], $validCategories)) {
                Response::error('INVALID_TICKET_CATEGORY', "The ticket category {$item['category']} is not sellable.");
            }
        }

        $addons = $productModel->getAddons($productId);
        $validAddonTypes = array_column($addons, 'addon_type');
        foreach ($addonItems as $item) {
            if (!in_array($item['addonType'], $validAddonTypes)) {
                Response::error('INVALID_ADDONS_CONFIGURATION', "The addon type {$item['addonType']} is not available.");
            }
        }

        // Create booking
        $bookingReference = uniqid('bk_');
        $bookingModel = new Booking();
        $tickets = $bookingModel->create([
            'booking_reference' => $bookingReference,
            'reservation_reference' => $reservationReference,
            'product_id' => $productId,
            'gyg_booking_reference' => $gygBookingReference,
            'date_time' => $dateTime,
            'currency' => $currency,
            'booking_items' => $bookingItems,
            'addon_items' => $addonItems,
            'travelers' => $travelers,
            'traveler_hotel' => $travelerHotel,
            'comment' => $comment
        ]);

        Response::success([
            'bookingReference' => $bookingReference,
            'tickets' => $tickets
        ]);
    }

    public function cancelBooking() {
        $input = json_decode(file_get_contents('php://input'), true);
        $data = $input['data'] ?? [];

        if (!isset($data['bookingReference'], $data['gygBookingReference'], $data['productId'])) {
            Response::error('VALIDATION_FAILURE', 'Missing required fields.');
        }

        $bookingReference = $data['bookingReference'];
        $bookingModel = new Booking();
        $booking = $bookingModel->getByReference($bookingReference);

        if (!$booking) {
            Response::error('INVALID_BOOKING', 'The specified booking does not exist.');
        }

        if ($booking['date_time'] < date('Y-m-d H:i:s')) {
            Response::error('BOOKING_IN_PAST', 'The booking is in the past.');
        }

        $bookingModel->delete($bookingReference);
        Response::success([]);
    }
}
?>