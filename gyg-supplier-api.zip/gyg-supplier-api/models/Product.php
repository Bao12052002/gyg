<?php
require_once __DIR__ . '/../utils/Database.php';

class Product {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function getById($productId) {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE product_id = ?");
        $stmt->execute([$productId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getBySupplier($supplierId) {
        $stmt = $this->db->prepare("SELECT product_id, product_title FROM products WHERE supplier_id = ?");
        $stmt->execute([$supplierId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getPricingCategories($productId) {
        $stmt = $this->db->prepare("SELECT * FROM pricing_categories WHERE product_id = ?");
        $stmt->execute([$productId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAddons($productId) {
        $stmt = $this->db->prepare("SELECT * FROM addons WHERE product_id = ?");
        $stmt->execute([$productId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>