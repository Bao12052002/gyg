<?php
require_once __DIR__ . '/../utils/Database.php';

class Reservation {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($data) {
        $this->db->beginTransaction();

        try {
            // Insert reservation
            $stmt = $this->db->prepare("
                INSERT INTO reservations (reservation_reference, product_id, gyg_booking_reference, date_time, reservation_expiration)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['reservation_reference'],
                $data['product_id'],
                $data['gyg_booking_reference'],
                $data['date_time'],
                $data['reservation_expiration']
            ]);

            // Insert reservation items
            foreach ($data['booking_items'] as $item) {
                $stmt = $this->db->prepare("
                    INSERT INTO reservation_items (reservation_reference, category, count)
                    VALUES (?, ?, ?)
                ");
                $stmt->execute([
                    $data['reservation_reference'],
                    $item['category'],
                    $item['count']
                ]);
            }

            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getByReference($reservationReference) {
        $stmt = $this->db->prepare("SELECT * FROM reservations WHERE reservation_reference = ?");
        $stmt->execute([$reservationReference]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function delete($reservationReference) {
        $this->db->beginTransaction();

        try {
            $stmt = $this->db->prepare("DELETE FROM reservation_items WHERE reservation_reference = ?");
            $stmt->execute([$reservationReference]);

            $stmt = $this->db->prepare("DELETE FROM reservations WHERE reservation_reference = ?");
            $stmt->execute([$reservationReference]);

            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}
?>