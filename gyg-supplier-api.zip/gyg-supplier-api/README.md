GetYourGuide Supplier API

This is a PHP-based system to integrate with GetYourGuide Supplier API (supplier-side endpoints).

Requirements





PHP >= 7.4



MySQL >= 5.7



Apache with mod_rewrite enabled

Installation





Setup Database:





Create a MySQL database named gyg_supplier_api.



Import the database_schema.sql file to create tables:

mysql -u root -p gyg_supplier_api < database_schema.sql



Configure Database:





Edit config/database.php with your database credentials:

return [
    'host' => 'localhost',
    'dbname' => 'gyg_supplier_api',
    'user' => 'your_username',
    'password' => 'your_password',
    'charset' => 'utf8mb4'
];



Setup Web Server:





Place the project in your web server's root directory (e.g., /var/www/html/gyg-supplier-api).



Ensure .htaccess is enabled in Apache.



Set the document root to the public/ directory.



Configure Authentication:





Edit utils/Auth.php to set your HTTP Basic Auth credentials:

$valid_username = 'your_username';
$valid_password = 'your_password';



Test the API:





Access the API endpoints via tools like Postman or curl.



Example: GET http://your-domain/1/get-availabilities?productId=tour123&fromDateTime=2025-06-01T00:00:00%2B02:00&toDateTime=2025-06-02T00:00:00%2B02:00

Endpoints





GET /1/get-availabilities: Query product availability.



POST /1/reserve: Create a temporary reservation.



POST /1/book: Confirm a booking.



POST /1/cancel-reservation: Cancel a temporary reservation.



POST /1/cancel-booking: Cancel a confirmed booking.



POST /1/notify: Receive notifications from GetYourGuide.



GET /1/suppliers/{supplierId}/products: List supplier products.



GET /1/products/{productId}: Get product details.



GET /1/products/{productId}/pricing-categories: Get pricing categories.



GET /1/products/{productId}/addons: Get addons.

Notes





Ensure all responses are JSON with Content-Type: application/json.



Always return HTTP status code 200 for valid responses, including errors.



Use ISO 8601 for date-time formats and ISO 4217 for currencies.



Monitor API performance to meet SLA (e.g., <4s for book, <3s for reserve).