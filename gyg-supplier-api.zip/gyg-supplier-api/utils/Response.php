<?php
class Response {
    public static function success($data) {
        header('Content-Type: application/json');
        http_response_code(200);
        echo json_encode(['data' => $data]);
        exit;
    }

    public static function error($errorCode, $errorMessage, $httpCode = 200) {
        header('Content-Type: application/json');
        http_response_code($httpCode);
        echo json_encode([
            'errorCode' => $errorCode,
            'errorMessage' => $errorMessage
        ]);
        exit;
    }
}
?>