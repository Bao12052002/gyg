<?php
require_once __DIR__ . '/../models/Notification.php';
require_once __DIR__ . '/../utils/Response.php';

class NotificationController {
    public function notify() {
        $input = json_decode(file_get_contents('php://input'), true);
        $data = $input['data'] ?? [];

        if (!isset($data['notificationType'], $data['description'], $data['dateTime'])) {
            Response::error('VALIDATION_FAILURE', 'Missing required fields.');
        }

        if ($data['notificationType'] !== 'PRODUCT_DEACTIVATION') {
            Response::error('VALIDATION_FAILURE', 'Unsupported notification type.');
        }

        $notificationModel = new Notification();
        $notificationModel->create($data);

        Response::success([]);
    }
}
?>