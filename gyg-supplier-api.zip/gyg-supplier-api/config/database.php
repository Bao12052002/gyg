<?php
return [
    'host' => 'localhost',
    'dbname' => 'gyg_supplier_api',
    'user' => 'root',
    'password' => '',
    'charset' => 'utf8mb4'
];
?>