<?php
require_once __DIR__ . '/../utils/Database.php';

class Booking {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($data) {
        $this->db->beginTransaction();

        try {
            // Insert booking
            $stmt = $this->db->prepare("
                INSERT INTO bookings (booking_reference, reservation_reference, product_id, gyg_booking_reference, 
                                     date_time, currency, traveler_hotel, comment)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['booking_reference'],
                $data['reservation_reference'],
                $data['product_id'],
                $data['gyg_booking_reference'],
                $data['date_time'],
                $data['currency'],
                $data['traveler_hotel'],
                $data['comment']
            ]);

            // Insert booking items
            foreach ($data['booking_items'] as $item) {
                $stmt = $this->db->prepare("
                    INSERT INTO booking_items (booking_reference, category, count, retail_price)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([
                    $data['booking_reference'],
                    $item['category'],
                    $item['count'],
                    $item['retailPrice']
                ]);
            }

            // Insert addon items
            foreach ($data['addon_items'] as $item) {
                $stmt = $this->db->prepare("
                    INSERT INTO addon_items (booking_reference, addon_type, count, retail_price, currency)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $data['booking_reference'],
                    $item['addonType'],
                    $item['count'],
                    $item['retailPrice'],
                    $data['currency']
                ]);
            }

            // Insert travelers
            foreach ($data['travelers'] as $traveler) {
                $stmt = $this->db->prepare("
                    INSERT INTO travelers (booking_reference, first_name, last_name, email, phone_number)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $data['booking_reference'],
                    $traveler['firstName'],
                    $traveler['lastName'],
                    $traveler['email'],
                    $traveler['phoneNumber']
                ]);
            }

            // Generate tickets
            $tickets = [];
            foreach ($data['booking_items'] as $item) {
                for ($i = 0; $i < $item['count']; $i++) {
                    $ticketCode = uniqid('ticket_');
                    $stmt = $this->db->prepare("
                        INSERT INTO tickets (booking_reference, category, ticket_code, ticket_code_type)
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $data['booking_reference'],
                        $item['category'],
                        $ticketCode,
                        'QR_CODE'
                    ]);
                    $tickets[] = [
                        'category' => $item['category'],
                        'ticketCode' => $ticketCode,
                        'ticketCodeType' => 'QR_CODE'
                    ];
                }
            }

            $this->db->commit();
            return $tickets;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getByReference($bookingReference) {
        $stmt = $this->db->prepare("SELECT * FROM bookings WHERE booking_reference = ?");
        $stmt->execute([$bookingReference]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function delete($bookingReference) {
        $this->db->beginTransaction();

        try {
            $stmt = $this->db->prepare("DELETE FROM tickets WHERE booking_reference = ?");
            $stmt->execute([$bookingReference]);

            $stmt = $this->db->prepare("DELETE FROM travelers WHERE booking_reference = ?");
            $stmt->execute([$bookingReference]);

            $stmt = $this->db->prepare("DELETE FROM addon_items WHERE booking_reference = ?");
            $stmt->execute([$bookingReference]);

            $stmt = $this->db->prepare("DELETE FROM booking_items WHERE booking_reference = ?");
            $stmt->execute([$bookingReference]);

            $stmt = $this->db->prepare("DELETE FROM bookings WHERE booking_reference = ?");
            $stmt->execute([$bookingReference]);

            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}
?>