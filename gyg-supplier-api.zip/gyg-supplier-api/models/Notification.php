<?php
require_once __DIR__ . '/../utils/Database.php';

class Notification {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO notifications (notification_type, description, supplier_name, integration_name, 
                                      date_time, product_id, gyg_tour_option_id, tour_option_title, 
                                      error_code, deactivation_date_time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['notificationType'],
            $data['description'],
            $data['supplierName'] ?? null,
            $data['integrationName'] ?? null,
            $data['dateTime'],
            $data['productDetails']['productId'] ?? null,
            $data['productDetails']['gygTourOptionId'] ?? null,
            $data['productDetails']['tourOptionTitle'] ?? null,
            $data['notificationDetails']['errorCode'] ?? null,
            $data['notificationDetails']['deactivationDateTime'] ?? null
        ]);
    }
}
?>