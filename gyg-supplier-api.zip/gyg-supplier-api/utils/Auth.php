<?php
class Auth {
    public static function authenticate() {
        // Thay bằng thông tin xác thực thực tế
        $valid_username = 'Onbird';
        $valid_password = '7a7d5a5f6cfbaf6572b3fc778dd81a33';

        if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
            header('WWW-Authenticate: Basic realm="Supplier API"');
            return false;
        }

        $username = $_SERVER['PHP_AUTH_USER'];
        $password = $_SERVER['PHP_AUTH_PW'];

        return $username === $valid_username && $password === $valid_password;
    }
}
?>