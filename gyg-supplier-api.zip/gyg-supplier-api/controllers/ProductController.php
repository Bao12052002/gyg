<?php
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../utils/Response.php';

class ProductController {
    public function getSupplierProducts($supplierId) {
        $productModel = new Product();
        $supplier = $productModel->getBySupplier($supplierId);

        if (empty($supplier)) {
            Response::error('INVALID_SUPPLIER', 'Supplier does not exist in the system.');
        }

        $products = array_map(function($product) {
            return [
                'productId' => $product['product_id'],
                'productTitle' => $product['product_title']
            ];
        }, $supplier);

        Response::success([
            'supplierId' => $supplierId,
            'supplierName' => 'Supplier Name', // Thay bằng tên thực tế
            'products' => $products
        ]);
    }

    public function getProductDetails($productId) {
        $productModel = new Product();
        $product = $productModel->getById($productId);

        if (!$product) {
            Response::error('INVALID_PRODUCT', 'The specified product does not exist.');
        }

        Response::success([
            'supplierId' => $product['supplier_id'],
            'productTitle' => $product['product_title'],
            'productDescription' => $product['product_description'],
            'destinationLocation' => [
                'city' => $product['destination_city'],
                'country' => $product['destination_country']
            ],
            'configuration' => [
                'min' => $product['min_participants'],
                'max' => $product['max_participants']
            ]
        ]);
    }

    public function getPricingCategories($productId) {
        $productModel = new Product();
        $product = $productModel->getById($productId);

        if (!$product) {
            Response::error('INVALID_PRODUCT', 'The specified product does not exist.');
        }

        $categories = $productModel->getPricingCategories($productId);
        $response = array_map(function($category) {
            return [
                'category' => $category['category'],
                'minTicketAmount' => $category['min_ticket_amount'],
                'maxTicketAmount' => $category['max_ticket_amount'],
                'groupSizeMin' => $category['group_size_min'],
                'groupSizeMax' => $category['group_size_max'],
                'ageFrom' => $category['age_from'],
                'ageTo' => $category['age_to'],
                'bookingCategory' => $category['booking_category'],
                'price' => [
                    'amount' => $category['price'],
                    'currency' => $category['currency']
                ]
            ];
        }, $categories);

        Response::success(['pricingCategories' => $response]);
    }

    public function getAddons($productId) {
        $productModel = new Product();
        $product = $productModel->getById($productId);

        if (!$product) {
            Response::error('INVALID_PRODUCT', 'The specified product does not exist.');
        }

        $addons = $productModel->getAddons($productId);
        $response = array_map(function($addon) {
            return [
                'addonType' => $addon['addon_type'],
                'retailPrice' => [
                    'amount' => $addon['retail_price'],
                    'currency' => $addon['currency']
                ],
                'addonDescription' => $addon['addon_description']
            ];
        }, $addons);

        Response::success(['addons' => $response]);
    }
}
?>